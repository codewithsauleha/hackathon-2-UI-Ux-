/** @type {import('next').NextConfig} */
const nextConfig = {
    experimental: {
      fontLoaders: ["@next/font/google", "@next/font/local"],
    },
  };
  
  module.exports = nextConfig;
  