export default function Cart() {
    return (
      <main className="py-16 px-6 container mx-auto">
        <h1 className="text-3xl font-bold mb-8 text-center">Your Cart</h1>
        <p className="text-lg text-center">Cart is empty right now. 🛒</p>
      </main>
    );
  }